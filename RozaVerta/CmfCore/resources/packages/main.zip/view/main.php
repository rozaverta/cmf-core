<?php defined("CMF_CORE") || exit;

/**
 * @var \RozaVerta\CmfCore\View\View $view
 */

?><!doctype html>
<html lang="<?= $view->item( "language" ) ?>">
<head>
	<meta charset="<?= $view->item( "charset" ) ?>">
	<meta name="viewport" content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
	<meta http-equiv="X-UA-Compatible" content="ie=edge">
	<title><?= $view->get( "pageTitle" ) ?></title>
	<link href="https://fonts.googleapis.com/css?family=Noto+Sans:400,400i,700,700i" rel="stylesheet">
	<style>
		body {
			margin: 0;
			padding: 0;
			font-family: monospace;
			font-size: 16px;
		}
		h1, h2, h3, h4, h5, h6 {
			line-height: 1;
			margin: 0 0 1.5em;
			color: #000;
		}
		h1 {
			margin-bottom: 0.8em;
		}
		strong {
			color: #000;
		}
		p {
			margin: 0 0 1.5em 0;
		}
		p:last-child {
			margin-bottom: 0;
		}
		.wrap {
			width: 800px;
			margin: 20px auto;
			position: relative;
		}
		.page {
			border-top: 1px solid #000;
		}
		.page__menu {
			font-size: 15px;
		}
		.page__text {
			padding-top: 30px;
			clear: left;
			color: #555;
		}
		.menu {
			margin: 0;
			padding: 0;
		}
		.menu__item {
			list-style: none;
			float: left;
		}
		.menu__item + .menu__item {
			margin-left: 2px;
		}
		.menu__link {
			display: inline-block;
			padding: 0.7em 1em;
			margin: 0;
			text-decoration: none;
			background: #efefef;
			border-top: 2px solid white;
			color: #000;
			transition: .3s color, .3s background-color;
		}
		.menu__link:hover,
		.menu__link_active {
			color: white;
			background: #000;
		}
		.menu__link_active {
			cursor: default;
			border-top-color: #000;
		}
		.warn {
			color: #900;
		}
		.links {
			padding-top: 30px;
			margin-bottom: -10px;
		}
		.links__item {
			display: inline-block;
			margin-right: 10px;
			margin-bottom: 10px;
			color: #0064e4;
			transition: .3s color;
		}
		.links__item:hover {
			color: #000;
		}
		@media screen and (max-width: 830px) {
			.wrap {
				width: auto;
				max-width: 800px;
				padding-left: 15px;
				padding-right: 15px;
			}
		}
	</style>
</head>
<body>
<div class="wrap">
	<h1><?= $view->get( "pageTitle" ) ?></h1>
	<div class="page"><?php

		// add welcome menu
		if( $view->item("controller.name") === "core::welcome" )
		{
			?><ul class="page__menu menu"><?php

			foreach($view->item("menu", []) as $page)
			{
				?><li class="menu__item"><a class="menu__link <?= $page["active"] ? " menu__link_active" : "" ?>" href="<?= $page["link"] ?>"><?= $page["title"] ?></a></li><?php
			}

			?></ul><?php
		}

		?><div class="page__text"><?= $view->getOn( "content" ) ?></div><?php

		$links = $view->item("links", []);
		if(is_array($links) && count($links))
		{
			?><div class="links"><?php
			foreach($links as $link) {
				?><a href="<?= $link["link"] ?>" class="links__item"><?= $link["title"] ?></a><?php
			}
			?></div><?php
		}

		?></div>
</div>
</body>
</html>